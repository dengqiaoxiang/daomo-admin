<?php

namespace addons\xshop\model;

class RefundLogModel extends Model
{
    protected $name = 'xshop_refundlog'; // 退款日志

}