<?php

namespace addons\xshop\model;

use think\Model as BaseModel;
use app\common\library\Auth;

class Model extends BaseModel
{
}
