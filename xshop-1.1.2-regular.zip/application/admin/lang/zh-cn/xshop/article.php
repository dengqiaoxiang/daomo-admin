<?php

return [
    'Title'       => '文章标题',
    'Description' => '文章描述',
    'Content'     => '内容',
    'Image'    => '缩略图',
    'Status'      => '状态',
    'Sort'        => '排序',
    'Create_time' => '创建时间',
    'Update_time' => '更新时间',
    'Delete_time' => '删除时间'
];
