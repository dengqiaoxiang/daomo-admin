<?php

return [
    'Category_id'        => '分类',
    'Title'              => '标题',
    'Description'        => '描述',
    'Content'            => '内容',
    'Image'              => '图片',
    'On_sale'            => '上下架',
    'Rating'             => '折扣',
    'Sold_count'         => '销售数量',
    'Review_count'       => '评价数量',
    'Price'              => '销售价',
    'Xshopcategory.name' => '分类名称',
    'Service_tags'       => '服务标签',
    'Create_time'       => '创建时间',
    'Update_time'       => '更新时间'
];
