<?php

return [
    'Parent_id'   => '上级分类',
    'Name'        => '分类名称',
    'Sort'        => '排序',
    'Create_time' => '创建时间',
    'Update_time' => '更新时间',
    'Image'       => '图片'
];
