<?php

return [
    'Title'       => '名称',
    'Description' => '描述'
];
