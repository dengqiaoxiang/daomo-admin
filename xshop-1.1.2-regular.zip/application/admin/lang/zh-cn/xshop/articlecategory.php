<?php

return [
    'Parent_id'   => '上级分类',
    'Title'       => '分类名称',
    'Description' => '分类描述',
    'Sort'      => '排序'
];
