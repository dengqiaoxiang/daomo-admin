<?php

namespace app\admin\model\xshop;

use think\Model;

/**
 * 中间表模型
 */
class Articlescategories extends Model
{
    protected $name = 'xshop_articles_categories';
}