export default {
	'msg.categories': {
		uri: 'index'
	},
	'msg.articles': {
		uri: 'index/articles'
	},
	'message.newMsgCount': {
		uri: 'index/newMsgCount'
	},
	'message.getUnViewCount': {
		uri: 'index/getUnViewCount'
	}
}