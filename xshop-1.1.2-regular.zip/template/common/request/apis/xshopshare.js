export default {
	'share.image': {
		uri: 'index/getShareImage'
	}
}