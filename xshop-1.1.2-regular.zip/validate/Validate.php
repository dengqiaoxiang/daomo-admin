<?php
namespace addons\xshop\validate;
use think\Validate as BaseValidate;
class Validate extends BaseValidate {
}