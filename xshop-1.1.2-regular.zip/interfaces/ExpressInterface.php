<?php

namespace addons\xshop\interfaces;

interface ExpressInterface
{
    public function query();
}